# Введение в Helm Chart CDC

Здесь вы найдёте:
* **samples** - примеры values.yml для разных CDC связок

## Helm-chart

Для получения чарта необходимо выполнить команду из корня репозитория (нужен доступ к vkcs s3):


```bash
make install_helm_chart
```

Или можно получить чарт из [поставки Tarantool CDC](https://confluence.vk.team/pages/viewpage.action?pageId=1339592083).
<br/>

```
helm-chart-cdc-x.x.x.tar.gz
```
<br/>

Этот helm chart можно использовать для установки, обновления и удаления приложений в кластере Kubernetes.
Chart обеспечивает согласованную работу приложений и упрощают процесс управления сущностями Tarantool CDC.

Helm chart можно использовать обособленно с установленным helm и kubernetes.  
Документация самого **helm-chart** находится ниже по документу: Helm Chart CDC

### Использование

В любом helm чарте можно задать настройки с помощью файла values и после создать запустить инстансы с помощью утилиты helm:
<br/>

```bash
helm install cdc ./cdc/ --values values.yaml
```
<br/>

Для debug'a можно использовать данную команду


```bash
helm template cdc ./cdc/ --values values.yaml
```

#### Samples

Дополнительно собраны примеры values.yml.
Найти их можно в [customer zone](https://www.tarantool.io/en/accounts/customer_zone/packages/tarantool-cdc)
<br/>

```
tarantool-cdc-helm-samples-x.x.x.tar.gz
```
<br/>

Их можно использовать как образец для определенной связки репликации: 
* [samples/corpcloud/cdc-tdg-click-example.yaml](samples/corpcloud/cdc-tdg2-clickhouse-example.yaml)
* [samples/corpcloud/cdc-oracle-pg-example.yaml](samples/corpcloud/cdc-oracle-pg-example.yaml)
* [samples/corpcloud/cdc-pg-pg-example.yaml](samples/corpcloud/cdc-pg-pg-example.yaml)
* [samples/corpcloud/cdc-pg-tdb-example.yaml](samples/corpcloud/cdc-pg-tdb-example.yaml)
* [samples/corpcloud/cdc-tdb-es-example.yaml](samples/corpcloud/cdc-tdb-es-example.yaml)
* [samples/corpcloud/cdc-tdb-pg-example.yaml](samples/corpcloud/cdc-tdb-pg-example.yaml)
* [samples/corpcloud/cdc-tdg2-es-example.yaml](samples/corpcloud/cdc-tdg2-elasticsearch-example.yaml)

Пример по созданию инстансов Tarantool CDC в кластере kubernetes:
<br/>

```bash
helm --namespace transfer install -f ./samples/corpcloud/cdc-pg-pg-example.yaml cdc ./cdc/
```

Конфигурирование инстансов кластера происходит внутри этих файлов.
<br/>

```bash
cp samples/corpcloud/cdc-pg-pg-example.yaml samples/public_cloud/cdc-pg-tdb-example.yaml
vim samples/public_cloud/cdc-pg-tdb-example.yaml
```

Например, поменять параметр host для postgres коннектора:
<br/>

```diff
- worker.connector.database.hostname: "postgresql-sourcedb-vm.cdc.local"
+ worker.connector.database.hostname: "10.0.4.1"
```
<br/>

##### Пример по разделению helm chart cdc на несколько чартов

> [!caution]
> Не работает в версии helm-chart-cdc 0.7.0 и 0.8.0. Ожидается фикс в 0.9.0+.

```bash
helm --namespace transfer install -f ./samples/corpcloud/cdc-oracle-tdb-example-only-tqe.yaml cdc ./cdc
### ждем пока TQE поднимется и запускаем workers
helm --namespace transfer install -f ./samples/corpcloud/cdc-oracle-tdb-example-only-workers.yaml cdcc ./cdc
```

### Советы по запуску

* При использовании кубер кластера в vkcs можно создать [docker registry addon](https://cloud.vk.com/docs/kubernetes/k8s/service-management/addons/advanced-installation/install-advanced-registry)
* Для деплоя helm-operator для разных сред придется менять файл config/manager/kustomization.yaml
  <br/>

  ```diff
  --- a/k8s/config/manager/kustomization.yaml
  +++ b/k8s/config/manager/kustomization.yaml
  @@ -4,12 +4,12 @@ patches:
   - patch: |-
       - op: add
         path: /spec/template/spec/imagePullSecrets
  -      value: [{ name: registry-gitlab }]
  +      value: [{ name: presale-registry }]
     target:
       kind: Deployment
   apiVersion: kustomize.config.k8s.io/v1beta1
   kind: Kustomization
   images:
   - name: controller
  -  newName: registry-gitlab.corp.mail.ru/tarantool/cdc/v9/tarantool-cdc/helm-operator
  +  newName: 89.208.221.175:5000/helm-operator
     newTag: 0.6.0
  ```
* Для корректного запуска в первую очередь необходимо задать имя образа. Например настройка может быть такой

  <br/>
  ```diff
     image:
  -    repository: worker-all
  +    repository: registry-gitlab.corp.mail.ru/tarantool/cdc/v9/tarantool-cdc/source-worker-all # registry_ip/source-worker-all
       pullPolicy: IfNotPresent
  -    tag: "latest"
  +    tag: "0.6.0
  ```
* Если используются сторонний registry, как в примере выше, то так же необходимо создать image secret
  в конкретный namespace. По умолчанию namespace называется k8s-system.
  <br/>
  
  ```bash
  k create namespace k8s-system
  k --namespace=k8s-system create secret docker-registry registry-gitlab \
  --docker-server=registry-gitlab.corp.mail.ru \
  --docker-username=<name> \
  --docker-password=<token> \
  --docker-email=<email>
  ```
  И прокинуть secret, чтобы он использовался в Deployment
  <br/>

  ```diff
  --- a/k8s/config/manager/kustomization.yaml
  +++ b/k8s/config/manager/kustomization.yaml
  @@ -1,2 +1,14 @@
   resources:
   - manager.yaml
  +patches:
  +- patch: |-
  +    - op: add
  +      path: /spec/template/spec/imagePullSecrets
  +      value: [{ name: registry-gitlab }]
  +  target:
  +    kind: Deployment
  ```
  И так же прописать в манифесте CR:
  <br/>

  ```diff
  -  imagePullSecrets: []
  +  imagePullSecrets:
  +    - name: registry-gitlab
  ```
* storageClass должен соответствовать той зоне, в которой находятся ваши ноды.
  Зону нод можно определить с помощью `k describe nodes`
  <br/>

  ```diff
    <     storageClass: csi-high-iops-ug1
    ---
    >     storageClass: standard
  ```
* удаляйте pvc перед каждым запуском,
  т.к. оператор не удаляет их и второй раз postjob будет пытаться поднимать топологию TQE,
  которая из-за pvc уже будет поднята
  <br/>

  ```
  k delete pvc --all --all-namespaces
  ```

